import React from 'react';
import {Switch,Route} from 'react-router-dom';
import Home from './Pages/Home';
import Features from './Pages/Features';
import Menu from './Pages/Menu';

import Contact from './Pages/Contact';
import Error from './Pages/Error';
import UserLayout from './Pages/UserLayout';
import DashBoard from './Component/Admin/DashBoard';
import Login from './Component/Login';
import Register from './Component/Register';
// import Cart from './Pages/Cart';
import 'bootstrap/dist/css/bootstrap.min.css';
import Payment from './Pages/Payment';




const App=()=>{
  return(
  <>
 
  <Switch>
    <Route exact path="/" exact component={Home}/>
    <Route path="/features" component={Features}/>
    <Route path="/menu" component={Menu}/>
  
    <Route path="/contact" component={Contact}/>
    <Route path="/login" component={Login}/>
    <Route path="/register" component={Register}/>
    <Route path="/userview" component={UserLayout}/>
    <Route path="/admin" exact component={DashBoard}/>
    {/* <Route path="/cart" exact component={Cart}/> */}
    <Route path="/payment" exact component={Payment}/>
   
    
    <Route component={Error}/>
  </Switch>
 
  </>
  )
}
export default App;