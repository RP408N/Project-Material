const items = [
    {
      id: 1,
      title: 'Sandwich',
      category: 'breakfast',
      price: 90,
      img: './breakfast/sandwich.jpg',
      
    },
    {
      id: 2,
      title: 'Paneer-Tikka',
      category: 'starters',
      price: 130,
      img: './Starters/paneer tikka.jpg',
       
    },
    {
      id: 3,
      title: 'Noodles',
      category: 'Chinese',
      price: 180,
      img: './Chinese/noodles.jpeg',
     
    },
    {
      id: 4,
      title: 'Masala Dosa',
      category: 'breakfast',
      price: 60,
      img: './breakfast/dosa1.jpg',
      
    },
    {
      id: 5,
      title: 'Kebabs',
      category: 'starters',
      price: 190,
      img: './Starters/kebabs1.jpg',
    
    },
    {
      id: 6,
      title: 'Manchurian',
      category: 'Chinese',
      price: 180,
      img: './Chinese/manchurian.jpg',
    },
    {
      id: 7,
      title: 'Idli',
      category: 'breakfast',
      price: 30,
      img: './breakfast/idli.jpg',
    },
    {
      id: 8,
      title: 'Pancakes',
      category: 'breakfast',
      price: 120,
      img: './breakfast/pancakes.jpg',
    }
    
  ];
  export default items;
  