package com.food.webapp.service;

import java.util.List;
import java.util.Set;

import com.food.webapp.model.User;




public interface UserService {
	
//	public User createUser(User user,Set<UserRole> userRoles) throws Exception;
//	public List<User> getAllUsers();
//	public User getUserByEmail(String email);
	      public User saveUser(User user);

}
